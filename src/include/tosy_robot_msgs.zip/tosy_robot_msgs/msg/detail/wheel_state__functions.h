// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from tosy_robot_msgs:msg/WheelState.idl
// generated code does not contain a copyright notice

#ifndef TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__FUNCTIONS_H_
#define TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "tosy_robot_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "tosy_robot_msgs/msg/detail/wheel_state__struct.h"

/// Initialize msg/WheelState message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * tosy_robot_msgs__msg__WheelState
 * )) before or use
 * tosy_robot_msgs__msg__WheelState__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__init(tosy_robot_msgs__msg__WheelState * msg);

/// Finalize msg/WheelState message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
void
tosy_robot_msgs__msg__WheelState__fini(tosy_robot_msgs__msg__WheelState * msg);

/// Create msg/WheelState message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * tosy_robot_msgs__msg__WheelState__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
tosy_robot_msgs__msg__WheelState *
tosy_robot_msgs__msg__WheelState__create();

/// Destroy msg/WheelState message.
/**
 * It calls
 * tosy_robot_msgs__msg__WheelState__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
void
tosy_robot_msgs__msg__WheelState__destroy(tosy_robot_msgs__msg__WheelState * msg);

/// Check for msg/WheelState message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__are_equal(const tosy_robot_msgs__msg__WheelState * lhs, const tosy_robot_msgs__msg__WheelState * rhs);

/// Copy a msg/WheelState message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__copy(
  const tosy_robot_msgs__msg__WheelState * input,
  tosy_robot_msgs__msg__WheelState * output);

/// Initialize array of msg/WheelState messages.
/**
 * It allocates the memory for the number of elements and calls
 * tosy_robot_msgs__msg__WheelState__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__Sequence__init(tosy_robot_msgs__msg__WheelState__Sequence * array, size_t size);

/// Finalize array of msg/WheelState messages.
/**
 * It calls
 * tosy_robot_msgs__msg__WheelState__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
void
tosy_robot_msgs__msg__WheelState__Sequence__fini(tosy_robot_msgs__msg__WheelState__Sequence * array);

/// Create array of msg/WheelState messages.
/**
 * It allocates the memory for the array and calls
 * tosy_robot_msgs__msg__WheelState__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
tosy_robot_msgs__msg__WheelState__Sequence *
tosy_robot_msgs__msg__WheelState__Sequence__create(size_t size);

/// Destroy array of msg/WheelState messages.
/**
 * It calls
 * tosy_robot_msgs__msg__WheelState__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
void
tosy_robot_msgs__msg__WheelState__Sequence__destroy(tosy_robot_msgs__msg__WheelState__Sequence * array);

/// Check for msg/WheelState message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__Sequence__are_equal(const tosy_robot_msgs__msg__WheelState__Sequence * lhs, const tosy_robot_msgs__msg__WheelState__Sequence * rhs);

/// Copy an array of msg/WheelState messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
bool
tosy_robot_msgs__msg__WheelState__Sequence__copy(
  const tosy_robot_msgs__msg__WheelState__Sequence * input,
  tosy_robot_msgs__msg__WheelState__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__FUNCTIONS_H_
