// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from tosy_robot_msgs:msg/WheelState.idl
// generated code does not contain a copyright notice

#ifndef TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__TYPE_SUPPORT_H_
#define TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "tosy_robot_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_tosy_robot_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  tosy_robot_msgs,
  msg,
  WheelState
)();

#ifdef __cplusplus
}
#endif

#endif  // TOSY_ROBOT_MSGS__MSG__DETAIL__WHEEL_STATE__TYPE_SUPPORT_H_
